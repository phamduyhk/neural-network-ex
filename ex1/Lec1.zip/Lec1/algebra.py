#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
第1回演習問題
"""
import numpy as np

########## 課題1(a)

########## 課題1(b)

########## 課題1(c)

########## 課題1(d)-i.

########## 課題1(d)-ii.